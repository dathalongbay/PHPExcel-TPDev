<?php
$data = file_get_contents("subject.json");
echo $data;